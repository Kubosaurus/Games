#ifndef BATS_H
#define BATS_H
#include "./event.h"

class bats : public event{
	private:
		
	public:
		void print_precept();
		void print_interact();
};
#endif /*BATS_H*/