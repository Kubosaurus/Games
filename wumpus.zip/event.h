#ifndef EVENT_H
#define EVENT_H

class event{
	private:
		
	public:
		virtual void print_precept() = 0;
		virtual void print_interact() = 0;
		
};
#endif /*EVENT_H*/