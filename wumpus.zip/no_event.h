#ifndef NO_EVENT_H
#define NO_EVENT_H
#include "./event.h"

class no_event : public event{
	private:
	
	public:
		void print_precept();
		void print_interact();
};
#endif /*NO_EVENT_H*/