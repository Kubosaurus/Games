#ifndef PITS_H
#define PITS_H
#include "./event.h"

class pits : public event{
	private:
		
	public:
		void print_precept();
		void print_interact();
};
#endif /*PITS_H*/